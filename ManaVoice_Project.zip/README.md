# ManaVoice
**Speak in Your Language. Get Things Done.**

A voice-first assistant prototype for people in India, especially rural communities and farmers. It supports Telugu, Hindi and English in the browser, provides demo answers, and includes a FastAPI backend with Docker Compose.

## Run locally (Docker)
```bash
docker compose up --build
```
Open:
- Frontend: http://localhost:5173
- Backend health: http://localhost:8000/health

## Run without Docker
Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Frontend (another terminal):
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```

## Prototype features
- Voice input using the browser Web Speech API where supported.
- Spoken answers using browser text-to-speech.
- Telugu, Hindi and English language selector.
- Demo responses for weather, farming, government schemes and general questions.
- Clear demo-data labels; no fabricated live weather or scheme status.
- Responsive dashboard and recent conversation list.

## Important limitations
This is a working prototype, not a production agricultural or government advisory service. Weather cards and sample answers are explicitly demo content. Browser speech recognition support varies by browser/device and may require an internet connection. Verify agricultural, medical, emergency and government information with official sources.

## Before public deployment
1. Replace demo answers with a trusted AI provider and server-side API key handling.
2. Integrate a verified weather provider and show source + last-updated time.
3. Add official government scheme data sources and citations.
4. Add consent, retention controls, rate limiting, monitoring and security review.
5. Deploy frontend/backend and configure HTTPS + allowed origins.

## GitHub submission
Create a public repository named `manavoice`, upload this project, and paste its repository URL into Scaler Flow. Do not publish API keys or private credentials.
