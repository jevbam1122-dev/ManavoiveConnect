from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="ManaVoice API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict this to your deployed frontend domain in production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AskRequest(BaseModel):
    message: str
    language: str = "te"

@app.get("/health")
def health():
    return {"status": "ok", "service": "ManaVoice API"}

@app.post("/api/ask")
def ask(payload: AskRequest):
    """Safe demo endpoint. Replace with a verified AI service before production."""
    msg = payload.message.strip().lower()
    lang = payload.language
    if any(k in msg for k in ["weather", "వాతావరణ", "मौसम"]):
        answers = {
            "te": "ఇది డెమో సమాధానం మాత్రమే. ఖచ్చితమైన వాతావరణ సమాచారం కోసం అధికారిక వాతావరణ సేవను చూడండి.",
            "hi": "यह केवल डेमो उत्तर है। सटीक मौसम जानकारी के लिए आधिकारिक मौसम सेवा देखें।",
            "en": "This is a demo response. Please check an official weather service for accurate local forecasts."
        }
    elif any(k in msg for k in ["crop", "పంట", "వరి", "खेती", "फसल"]):
        answers = {
            "te": "పంట సమస్యను బట్టి సలహా మారుతుంది. పంట రకం, లక్షణాలు, ప్రాంతం వివరాలతో స్థానిక వ్యవసాయ అధికారిని సంప్రదించండి. ఇది సాధారణ డెమో సమాచారం మాత్రమే.",
            "hi": "फसल की समस्या के अनुसार सलाह बदलती है। फसल, लक्षण और क्षेत्र की जानकारी के साथ स्थानीय कृषि अधिकारी से सलाह लें।",
            "en": "Crop advice depends on the crop, symptoms and region. Please consult a local agricultural officer for situation-specific guidance."
        }
    elif any(k in msg for k in ["scheme", "పథకం", "योजना"]):
        answers = {
            "te": "ప్రభుత్వ పథకాల అర్హతలు మారవచ్చు. తాజా వివరాలు మరియు దరఖాస్తు కోసం సంబంధిత అధికారిక ప్రభుత్వ పోర్టల్‌ను తనిఖీ చేయండి.",
            "hi": "सरकारी योजनाओं की पात्रता बदल सकती है। नवीनतम जानकारी के लिए संबंधित आधिकारिक सरकारी पोर्टल देखें।",
            "en": "Eligibility can change. Check the relevant official government portal for current details and applications."
        }
    else:
        answers = {
            "te": "నమస్కారం! మీ ప్రశ్న అందింది. ఇది ManaVoice డెమో. మరింత ఖచ్చితమైన సమాధానాల కోసం AI సేవను అనుసంధానించాలి.",
            "hi": "नमस्ते! आपका सवाल मिल गया। यह ManaVoice डेमो है। बेहतर जवाबों के लिए AI सेवा जोड़नी होगी।",
            "en": "Hello! I received your question. This is the ManaVoice demo; connect an AI service for richer answers."
        }
    return {"answer": answers.get(lang, answers["en"]), "demo": True}
