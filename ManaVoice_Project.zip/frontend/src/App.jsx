import React, { useEffect, useRef, useState } from "react";
import { Mic, Volume2, CloudSun, Sprout, Landmark, MapPin, Send, Leaf, Menu, History, Settings2, Globe2, Waves, CircleHelp } from "lucide-react";

const copy = {
  te: { greeting:"నమస్కారం! మీకు ఎలా సహాయం చేయగలను?", subtitle:"మీ భాషలో మాట్లాడండి. సమాధానం వినండి.", listen:"మాట్లాడటానికి నొక్కండి", listening:"వింటున్నాను…", placeholder:"లేదా ఇక్కడ టైప్ చేయండి…", weather:"వాతావరణం", farming:"వ్యవసాయ సహాయం", schemes:"ప్రభుత్వ పథకాలు", nearby:"దగ్గరలో సేవలు", recent:"ఇటీవలి సంభాషణలు", demo:"డెమో సమాచారం", send:"పంపండి" },
  hi: { greeting:"नमस्ते! मैं आपकी कैसे मदद कर सकता हूँ?", subtitle:"अपनी भाषा में बोलें। जवाब सुनें।", listen:"बोलने के लिए टैप करें", listening:"सुन रहा हूँ…", placeholder:"या यहाँ टाइप करें…", weather:"मौसम", farming:"खेती में मदद", schemes:"सरकारी योजनाएँ", nearby:"आस-पास सेवाएँ", recent:"हाल की बातचीत", demo:"डेमो जानकारी", send:"भेजें" },
  en: { greeting:"Hello! How can I help you today?", subtitle:"Speak in your language. Hear your answer.", listen:"Tap to speak", listening:"Listening…", placeholder:"Or type your question here…", weather:"Weather updates", farming:"Farming help", schemes:"Government schemes", nearby:"Nearby services", recent:"Recent conversations", demo:"Demo information", send:"Send" }
};
const locale = {te:"te-IN", hi:"hi-IN", en:"en-IN"};
const quick = [{key:"weather", icon:CloudSun, color:"gold"},{key:"farming",icon:Sprout,color:"green"},{key:"schemes",icon:Landmark,color:"blue"},{key:"nearby",icon:MapPin,color:"purple"}];

export default function App(){
  const [lang,setLang]=useState("te"), [listening,setListening]=useState(false), [input,setInput]=useState("");
  const [messages,setMessages]=useState([]), [busy,setBusy]=useState(false), [active,setActive]=useState("home");
  const recognition=useRef(null);
  const t=copy[lang];
  useEffect(()=>{ if("speechSynthesis" in window) window.speechSynthesis.cancel(); },[lang]);
  function speak(text){ if(!("speechSynthesis" in window)) return; window.speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang=locale[lang]; u.rate=.94; window.speechSynthesis.speak(u); }
  function startVoice(){
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){ alert("Voice recognition is not available in this browser. Try a supported browser or type your question."); return; }
    if(listening){ recognition.current?.stop(); setListening(false); return; }
    const r=new SR(); recognition.current=r; r.lang=locale[lang]; r.interimResults=true; r.continuous=false;
    r.onstart=()=>setListening(true); r.onend=()=>setListening(false);
    r.onerror=()=>setListening(false);
    r.onresult=(e)=>{let value=""; for(let i=e.resultIndex;i<e.results.length;i++) value+=e.results[i][0].transcript; setInput(value); if(e.results[e.results.length-1].isFinal) send(value);};
    r.start();
  }
  async function send(text=input){
    const value=text.trim(); if(!value||busy)return;
    setMessages(m=>[...m,{role:"user",text:value}]); setInput(""); setBusy(true);
    let answer="";
    try{
      const res=await fetch((import.meta.env.VITE_API_URL||"http://localhost:8000")+"/api/ask",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:value,language:lang})});
      if(!res.ok) throw new Error("API unavailable"); const data=await res.json(); answer=data.answer;
    }catch{
      answer=lang==="te"?"ఇది ManaVoice డెమో. Backend ప్రారంభించిన తర్వాత మరిన్ని సమాధానాలు అందుబాటులో ఉంటాయి.":lang==="hi"?"यह ManaVoice डेमो है। बैकएंड शुरू करने पर और जवाब उपलब्ध होंगे।":"This is the ManaVoice demo. Start the backend for more responses.";
    }
    setMessages(m=>[...m,{role:"assistant",text:answer}]); setBusy(false); speak(answer);
  }
  const selectQuick=(key)=>{
    const prompts={weather:{te:"రేపు వాతావరణం ఎలా ఉంటుంది?",hi:"कल मौसम कैसा रहेगा?",en:"What will the weather be like tomorrow?"},farming:{te:"వరి పంటకు సంబంధించిన సూచనలు చెప్పండి",hi:"धान की फसल के बारे में सलाह दें",en:"Give me general advice about paddy farming"},schemes:{te:"రైతులకు అందుబాటులో ఉన్న ప్రభుత్వ పథకాలు ఏమిటి?",hi:"किसानों के लिए कौन सी सरकारी योजनाएँ हैं?",en:"What government schemes are available for farmers?"},nearby:{te:"దగ్గరలో వ్యవసాయ సేవలు ఎలా కనుగొనాలి?",hi:"आस-पास कृषि सेवाएँ कैसे खोजें?",en:"How can I find nearby agricultural services?"}};
    send(prompts[key][lang]);
  };
  return <div className="app">
    <header className="topbar"><div className="brand"><div className="brandmark"><Waves size={23}/></div><div><b>ManaVoice</b><small>Speak in Your Language</small></div></div><div className="top-actions"><span className="live"><i/> Prototype</span><select aria-label="Language" value={lang} onChange={e=>setLang(e.target.value)}><option value="te">తెలుగు</option><option value="hi">हिन्दी</option><option value="en">English</option></select></div></header>
    <main className="layout">
      <aside className="sidebar"><button className={active==="home"?"nav active":"nav"} onClick={()=>setActive("home")}><Menu size={18}/> Home</button><button className={active==="history"?"nav active":"nav"} onClick={()=>setActive("history")}><History size={18}/> {t.recent}</button><button className={active==="settings"?"nav active":"nav"} onClick={()=>setActive("settings")}><Settings2 size={18}/> Settings</button><div className="side-note"><Leaf size={19}/><b>Technology for Everyone</b><p>Making useful information easier to access through voice.</p></div></aside>
      <section className="content">
        {active==="home"&&<><div className="hero"><div className="eyebrow"><span/> YOUR VOICE-FIRST ASSISTANT</div><h1>{t.greeting}</h1><p>{t.subtitle}</p>
          <button className={`mic ${listening?"is-listening":""}`} onClick={startVoice}><span className="mic-ring"><Mic size={35}/></span></button><b className="listen-label">{listening?t.listening:t.listen}</b><small className="hint">Telugu · Hindi · English</small>
          <div className="wave">{[12,22,32,18,40,25,15,34,20,12,28,16,35,22,12].map((h,i)=><i key={i} style={{height:h}}/>)}</div>
        </div>
        <div className="quick-head"><div><h2>Explore ManaVoice</h2><p>Choose a topic or ask in your own words</p></div><span className="demo-pill">{t.demo}</span></div>
        <div className="cards">{quick.map(({key,icon:Icon,color})=><button className="quick-card" key={key} onClick={()=>selectQuick(key)}><span className={`qicon ${color}`}><Icon size={22}/></span><b>{t[key]}</b><span className="arrow">↗</span></button>)}</div>
        <div className="chat-panel"><div className="chat-title"><div><h2>Ask ManaVoice</h2><p>Speak or type a question</p></div><span className="secure"><Globe2 size={14}/> Local language</span></div>
          <div className="messages">{messages.length===0?<div className="empty"><CircleHelp size={24}/><p>Your conversation will appear here.</p><small>Try asking about weather, farming or government schemes.</small></div>:messages.map((m,i)=><div className={`message ${m.role}`} key={i}><span>{m.role==="user"?"You":"ManaVoice"}</span><p>{m.text}</p>{m.role==="assistant"&&<button className="replay" onClick={()=>speak(m.text)}><Volume2 size={15}/> Listen</button>}</div>)}{busy&&<div className="typing">ManaVoice is thinking…</div>}</div>
          <form className="composer" onSubmit={e=>{e.preventDefault();send();}}><input value={input} onChange={e=>setInput(e.target.value)} placeholder={t.placeholder}/><button type="submit" disabled={!input.trim()||busy}><Send size={18}/><span>{t.send}</span></button></form>
        </div>
        </>}
        {active==="history"&&<div className="simple-page"><h1>{t.recent}</h1><p>Your recent questions from this session.</p>{messages.length?messages.map((m,i)=><div className="history-item" key={i}><b>{m.role==="user"?"You":"ManaVoice"}</b><p>{m.text}</p></div>):<p>No conversations yet. Start by asking ManaVoice a question.</p>}</div>}
        {active==="settings"&&<div className="simple-page"><h1>Settings</h1><p>Choose your preferred language.</p><select value={lang} onChange={e=>setLang(e.target.value)}><option value="te">తెలుగు</option><option value="hi">हिन्दी</option><option value="en">English</option></select><p className="disclaimer">Voice recognition availability depends on your browser and device. Your prototype conversations are stored only in the current page session.</p></div>}
        <footer><span>ManaVoice © 2026</span><span>Built for inclusion in India</span></footer>
      </section>
    </main>
  </div>;
}
